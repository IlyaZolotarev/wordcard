export default function Category() {
    return (
        null
    )
}
