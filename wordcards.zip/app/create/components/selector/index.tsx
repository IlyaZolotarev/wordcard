import { useEffect, useState, useCallback } from "react";
import {
    View,
    StyleSheet,
    Text,
    TouchableOpacity,
    ActivityIndicator,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";

export default function CreateScreen() {
    const { user } = useAuth();
    const [dropdownVisible, setDropdownVisible] = useState(false);
    const [categories, setCategories] = useState<{ id: string; name: string }[]>(
        []
    );
    const [selectedCategory, setSelectedCategory] = useState<{
        id: string;
        name: string;
    } | null>(null);
    const [loadingCategories, setLoadingCategories] = useState(true);

    const fetchCategories = useCallback(async () => {
        if (!user) return;
        setLoadingCategories(true);
        const { data, error } = await supabase
            .from("categories")
            .select("id, name")
            .eq("user_id", user.id);

        if (!error && data) {
            setCategories(data);
            setSelectedCategory(data[0] || null);
        }
        setLoadingCategories(false);
    }, [user]);

    useEffect(() => {
        fetchCategories();
    }, [fetchCategories]);

    return (
        <View style={styles.base}>
            <TouchableOpacity
                style={[
                    styles.dropdown,
                    !categories.length && styles.dropdownDisabled,
                ]}
                onPress={() =>
                    categories.length && setDropdownVisible(!dropdownVisible)
                }
                disabled={loadingCategories || !categories.length}
            >
                {loadingCategories ? (
                    <ActivityIndicator size="small" color="#aaa" />
                ) : categories.length ? (
                    <Text style={styles.dropdownText}>{selectedCategory?.name}</Text>
                ) : (
                    <Ionicons name="alert-circle-outline" size={20} color="#aaa" />
                )}
            </TouchableOpacity>

            {dropdownVisible && categories.length > 0 && (
                <View style={styles.dropdownOverlay}>
                    <View style={styles.dropdownMenu}>
                        {categories.map((cat) => (
                            <TouchableOpacity
                                key={cat.id}
                                style={styles.menuItem}
                                onPress={() => {
                                    setSelectedCategory(cat);
                                    setDropdownVisible(false);
                                }}
                            >
                                <Text style={styles.menuItemText}>{cat.name}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                </View>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    base: {
        position: "relative",
        marginBottom: 12,
    },
    dropdown: {
        paddingVertical: 12,
        paddingHorizontal: 16,
        borderRadius: 24,
        borderWidth: 1,
        borderColor: "#bbb",
        backgroundColor: "#fff",
        alignItems: "center",
    },
    dropdownDisabled: {
        opacity: 0.5,
    },
    dropdownText: {
        fontSize: 16,
        color: "#333",
    },
    dropdownOverlay: {
        position: "absolute",
        top: 50,
        width: "100%",
        zIndex: 10,
    },
    dropdownMenu: {
        backgroundColor: "#fff",
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#ddd",
        paddingVertical: 8,
    },
    menuItem: {
        paddingVertical: 10,
        paddingHorizontal: 16,
    },
    menuItemText: {
        fontSize: 16,
        color: "#333",
    },
});
