import { useRef, useEffect } from "react"
import {
    View,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    Animated,
} from "react-native"
import { triggerShake } from '@/lib/utils';

enum ERROR_TYPE {
    textType = 'textType',
    transTextType = 'transTextType'
}

type wordInputsProps = {
    text: string,
    transText: string,
    onChangeText: (text: string) => void
    onChangeTransText: (text: string) => void
    onSwapText: () => void
    hasError: boolean

}

export default function WordInputs({ text, transText, onChangeText, onChangeTransText, onSwapText, hasError }: wordInputsProps) {
    const inputWordShake = useRef(new Animated.Value(0)).current

    useEffect(() => {
        if (hasError) triggerShake(inputWordShake)
    })

    return (
        <View style={styles.base}>
            <Animated.View style={[styles.inputWrapper, { transform: [{ translateX: inputWordShake }] }]}>
                <TextInput
                    placeholder="..."
                    value={text}
                    onChangeText={onChangeText}
                    style={[styles.input, hasError && styles.inputError]}
                />
            </Animated.View>

            <TouchableOpacity onPress={onSwapText} style={styles.swapBtn}>
                <Text style={styles.swapText}>⇄</Text>
            </TouchableOpacity>

            <View style={styles.inputWrapper}>
                <TextInput
                    placeholder="..."
                    value={transText}
                    onChangeText={onChangeTransText}
                    style={styles.input}
                />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    base: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 16,
    },
    inputWrapper: {
        flex: 1,
    },
    input: {
        borderBottomWidth: 1,
        borderColor: "#ddd",
        backgroundColor: "transparent",
        fontSize: 24,
        marginBottom: 16,
        textAlign: 'center'
    },
    inputError: {
        borderColor: "red",
    },
    swapBtn: {
        paddingHorizontal: 8,
    },
    swapText: {
        fontSize: 26,
        color: "#555",
    },
})