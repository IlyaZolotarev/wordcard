export default function Search() {
    return (
        null
    )
}
