import { useRouter, usePathname } from "expo-router"
import { IconButton } from "react-native-paper"
import { View, StyleSheet, TextInput } from "react-native"
import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/useAuth"
import { Keyboard } from "react-native"
export default function Header() {
    const router = useRouter()
    const pathname = usePathname()
    const { user } = useAuth()
    const [query, setQuery] = useState("")
    const [hasError, setHasError] = useState(false)
    const showBack = user && pathname !== "/home" && pathname !== "/"

    useEffect(() => {
        const sub = Keyboard.addListener("keyboardDidHide", () => {
            setHasError(false)
        })

        return () => sub.remove()
    }, [])

    const handleSubmit = () => {
        if (!query.trim()) {
            setHasError(true)
            return
        }
    }

    return (
        <View style={styles.wrapper}>
            <View style={styles.inner}>
                {showBack && (
                    <IconButton
                        icon="arrow-left"
                        size={24}
                        onPress={() => router.back()}
                    />
                )}
                <View style={styles.searchContainer}>
                    <TextInput
                        value={query}
                        onChangeText={setQuery}
                        placeholder="..."
                        placeholderTextColor="#aaa"
                        style={[styles.input, hasError && styles.inputError]}
                    />
                    <IconButton
                        icon="magnify"
                        size={22}
                        onPress={handleSubmit}
                        style={styles.searchIcon}
                    />
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    wrapper: {
        paddingTop: 8,
        paddingBottom: 12,
    },
    inner: {
        flexDirection: "row",
        alignItems: "center",
    },
    searchContainer: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        borderBottomWidth: 1,
        borderColor: "#ddd",
        flex: 1,
        backgroundColor: "transparent",
        height: 44,
    },
    inputError: {
        borderColor: "red",
    },
    searchIcon: {
        marginLeft: 4,
    },
})
